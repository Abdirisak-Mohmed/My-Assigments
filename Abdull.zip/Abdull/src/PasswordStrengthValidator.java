import java.util.*;

public class PasswordStrengthValidator {

    public static boolean isLongEnough(String password) {
        return password.length() >= 8;
    }

    public static boolean hasUppercase(String password) {
        for (char ch : password.toCharArray()) {
            if (Character.isUpperCase(ch)) {
                return true;
            }
        }
        return false;
    }

    public static boolean hasLowercase(String password) {
        for (char ch : password.toCharArray()) {
            if (Character.isLowerCase(ch)) {
                return true;
            }
        }
        return false;
    }

    public static boolean hasDigit(String password) {
        for (char ch : password.toCharArray()) {
            if (Character.isDigit(ch)) {
                return true;
            }
        }
        return false;
    }

    public static boolean hasSpecialCharacter(String password) {
        for (char ch : password.toCharArray()) {
            if (!Character.isLetterOrDigit(ch)) {
                return true;
            }
        }
        return false;
    }

    public static boolean isStrongPassword(String password) {
        return isLongEnough(password) &&
                hasUppercase(password) &&
                hasLowercase(password) &&
                hasDigit(password) &&
                hasSpecialCharacter(password);
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a password to check: ");
        String password = input.nextLine();

        if (isStrongPassword(password)) {
            System.out.println("Password is strong.");
        } else {
            System.out.println("Password is weak. Make sure it:");
            if (!isLongEnough(password)) {
                System.out.println("- Is at least 8 characters long");
            }
            if (!hasUppercase(password)) {
                System.out.println("- Has at least one uppercase letter");
            }
            if (!hasLowercase(password)) {
                System.out.println("- Has at least one lowercase letter");
            }
            if (!hasDigit(password)) {
                System.out.println("- Has at least one digit");
            }
            if (!hasSpecialCharacter(password)) {
                System.out.println("- Has at least one special character");
            }
        }
    }
}

public class passwordChecker {


    }





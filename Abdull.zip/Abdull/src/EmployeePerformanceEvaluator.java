public class EmployeePerformanceEvaluator {
    public static void main(String[] args) {
        int[] scores = {45,67,81,90,34,76,49,58};
        int greaterThan = 75;
        int count=0;
        for(int i =0;i<scores.length;i++){
            if (scores[i]>greaterThan){
                System.out.println("The Number That's > 75 is: "+ scores[i]);
            }
        }
        
        int countBelow50 = 0;
        for (int score : scores){
            if (score>50){
                countBelow50++;
            }
        }
        System.out.println("Number of employees who need improvement (score below 50): " + countBelow50);


    }

}


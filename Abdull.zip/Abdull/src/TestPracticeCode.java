import java.util.Random;
import java.util.Scanner;

public class TestPracticeCode {

    // Method to calculate area of rectangle
    public static double calculateRectangleArea(double width, double height) {return width * height;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Part 1: Calculate area of rectangle
        System.out.println("Enter the width of the rectangle:");
        double width = scanner.nextDouble();
        System.out.println("Enter the height of the rectangle:");
        double height = scanner.nextDouble();

        double area = calculateRectangleArea(width, height);
        System.out.printf("The area of the rectangle is: %.2f\n\n", area);

        // Part 2: Array operations
        // a. Create array with 10 random values
        int[] numbers = new int[10];
        Random random = new Random();

        System.out.println("Array with 10 random values:");
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = random.nextInt(100); // Random numbers between 0-99
        }

        // b. Print all elements using for loop
        System.out.println("Printing using for loop:");
        for (int number : numbers) {
            System.out.print(number + " ");
        }
        System.out.println();

        // Print all elements using foreach loop
        System.out.println("Printing using foreach loop:");
        for (int num : numbers) {
            System.out.print(num + " ");
        }
        System.out.println("\n");

        // c. Find minimum element and its position
        int min = numbers[0];
        int position = 0;

        for (int i = 1; i < numbers.length; i++) {
            if (numbers[i] < min) {
                min = numbers[i];
                position = i;
            }
        }

        System.out.println("The minimum element is: " + min);
        System.out.println("It is at position: " + position + " (0-based index)");

        scanner.close();
    }
}

public class ArraysPart2 {
    public static void main(String[] args) {
//        int[] numbers={3,54,89,0,3,2,5};
//        for (int e :numbers) System.out.println(e);
//        int [] myNumbers=generateNumbers();
//        int total=sum(myNumbers);
//        int count=aboveAverage(total,myNumbers);
//
//        for (int e:myNumbers){
//            System.out.println(e);
//        }
//        System.out.println("the sum is:"+total);
//        System.out.println("the numbers above average is: "+ count);


        int [] evens={2,4,6,8,10,12};
        int [] target=new int[evens.length];
//        System.arraycopy(evens,3,target,3,3);
//        for (int e: target){
//            System.out.println(e);
//        }

        for (int i=0;i<evens.length;i++){
            target[i]=evens[i];

        }
        for (int e: evens){
            System.out.println(e);
        }
        target[2]=99;

        for (int e: target){
            System.out.println(e);
        }
    }

    public static int[] generateNumbers(){
        int[] numbers=new int[100];
        for (int i=0 ; i<numbers.length;i++){
            numbers[i]=(int)(Math.random()*100);
        }
        return numbers;
    }

    public static int sum(int[] numbers){
        int total=0;
        for(int i =0;i<numbers.length;i++){
            total+=numbers[i];
        }
        return total;

    }

    public static int aboveAverage(int total,int[] numbers){
        int avarage=total/numbers.length;
        int count=0;
        for (int element: numbers){
            if (element>avarage){
                count++;
            }
        }
        System.out.println("the average is: "+  avarage);
        return count;
    }


}

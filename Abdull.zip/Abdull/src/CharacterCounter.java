import java.util.Scanner;

public class CharacterCounter {

    // Method to count uppercase letters
    public static int countUppercase(String sentence) {
        int count = 0;
        for (char ch : sentence.toCharArray()) {
            if (Character.isUpperCase(ch)) {
                count++;
            }
        }
        return count;
    }

    // Method to count lowercase letters
    public static int countLowercase(String sentence) {
        int count = 0;
        for (char ch : sentence.toCharArray()) {
            if (Character.isLowerCase(ch)) {
                count++;
            }
        }
        return count;
    }

    // Method to count digits
    public static int countDigits(String sentence) {
        int count = 0;
        for (char ch : sentence.toCharArray()) {
            if (Character.isDigit(ch)) {
                count++;
            }
        }
        return count;
    }

    // Method to count special characters
    public static int countSpecialCharacters(String sentence) {
        int count = 0;
        for (char ch : sentence.toCharArray()) {
            if (!Character.isLetterOrDigit(ch)) {
                count++;
            }
        }
        return count;
    }

    // Main method
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter a sentence: ");
        String sentence = input.nextLine();

        int uppercaseCount = countUppercase(sentence);
        int lowercaseCount = countLowercase(sentence);
        int digitCount = countDigits(sentence);
        int specialCharCount = countSpecialCharacters(sentence);

        System.out.println("Uppercase letters: " + uppercaseCount);
        System.out.println("Lowercase letters: " + lowercaseCount);
        System.out.println("Digits: " + digitCount);
        System.out.println("Special characters: " + specialCharCount);
    }
}
